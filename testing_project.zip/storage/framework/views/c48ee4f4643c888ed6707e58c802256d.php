<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\TA\testing cf\REVISI_PROJECT\testing_project\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>