<div class="modal fade" id="ModalGejala" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <div class="section-body">
                    <div class="row">
                        <div class="col-12">
                            <form method="POST" action="<?php echo e(route('admin/gejala/store')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="card-header">
                                    <h4>Tambahkan Data Gejala</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label>Kode Gejala</label>
                                        <input type="text" class="form-control" name="kode_gejala">
                                        <?php $__errorArgs = ['kode_gejala'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text text-danger">
                                                <?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label>Nama Gejala</label>
                                        <input type="text" class="form-control" name="nama_gejala">
                                        <?php $__errorArgs = ['nama_gejala'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text text-danger">
                                                <?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="card-footer text-right">
                                        <button class="btn btn-primary">Submit</button>
                                    </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\TA\testing cf\REVISI_PROJECT\testing_project\resources\views/Admin/gejala/create.blade.php ENDPATH**/ ?>