    <!-- Modal EDIT -->
    <div class="modal fade" id="modal-edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Edit Data Pernyataan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="<?php echo e(route('admin/rule/update', 'rule')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>Kode Rule</label>
                            <input type="text" class="form-control" name="rule" id="rule" readonly>
                            <?php $__errorArgs = ['rule'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text text-danger">
                                    <?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label>Nama gejala</label>
                            <select class="form-select" name="gejala_id" id="gejala_id">
                                <?php $__currentLoopData = $data_gejala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gejala): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($gejala->kode_gejala); ?>">
                                        <?php echo e($gejala->nama_gejala); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group mb-0">
                            <label>Pernyataan</label>
                            <select class="form-select" name="pernyataan_id" id="pernyataan_id">
                                <?php $__currentLoopData = $pernyataan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule_pernyataan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($rule_pernyataan->kode_pernyataan); ?>">
                                        <?php echo e($rule_pernyataan->pernyataan); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Nilai MB</label>
                            <input type="number" step="0.1"class="form-control" name="nilai_mb" id="nilai_mb">
                            <?php $__errorArgs = ['nilai_mb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text text-danger">
                                    <?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label>Nilai MD</label>
                            <input type="number" step="0.1"class="form-control" name="nilai_md" id="nilai_md">
                            <?php $__errorArgs = ['nilai_md'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text text-danger">
                                    <?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label>Nilai CF</label>
                            <input type="number" class="form-control" name="nilai_cf" id="nilai_cf" readonly>
                            <?php $__errorArgs = ['nilai_cf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text text-danger">
                                    <?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Menambahkan event listener untuk memantau perubahan pada input nilai_md
        document.querySelector('input[name="nilai_md"]').addEventListener('input', function() {
            // Ambil nilai dari input nilai_mb dan nilai_md
            var nilai_mb = parseFloat(document.querySelector('input[name="nilai_mb"]').value);
            var nilai_md = parseFloat(document.querySelector('input[name="nilai_md"]').value);

            // Hitung nilai_cf
            var nilai_cf = nilai_mb - nilai_md;

            // Masukkan nilai_cf ke dalam input nilai_cf
            document.querySelector('input[name="nilai_cf"]').value = nilai_cf.toFixed(
                2); // Memperbaiki nilai_cf menjadi dua angka di belakang koma
        });
    </script>
<?php /**PATH D:\TA\testing cf\REVISI_PROJECT\testing_project\resources\views/Admin/Rule/edit.blade.php ENDPATH**/ ?>