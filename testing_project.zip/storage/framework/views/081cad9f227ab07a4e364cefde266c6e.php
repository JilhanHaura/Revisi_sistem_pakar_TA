<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Data Pernyataan</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="<?php echo e(route('admin/home')); ?>">Dashboard</a></div>
                    <div class="breadcrumb-item">Data Pernyataan</div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <?php if(session()->has('pesan')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('pesan')); ?> </div>
                            <?php endif; ?>
                            <div class="d-flex justify-content-end mb-3">
                                <a class="btn btn-success active" href="#" data-toggle="modal"
                                    data-target="#ModalPernyataan">Add Data</a>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-striped" id="table-1">
                                    <thead>
                                        <tr>
                                            <th class="text-center">
                                                #
                                            </th>
                                            <th>Kode Pernyataan</th>
                                            <th>Nama Pernyataan</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $pernyataan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_pernyataan_admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                                <td><?php echo e($data_pernyataan_admin->kode_pernyataan); ?></td>
                                                <td><?php echo e($data_pernyataan_admin->pernyataan); ?></td>
                                                <td>
                                                    <a class="btn btn-primary active"
                                                        data-kode_pernyataan="<?php echo e($data_pernyataan_admin->kode_pernyataan); ?>"
                                                        data-pernyataan="<?php echo e($data_pernyataan_admin->pernyataan); ?>"
                                                        data-toggle="modal" data-target="#modal-edit">edit</a>
                                                    <form
                                                        action="<?php echo e(route('admin.pernyataan.destroy', $data_pernyataan_admin->kode_pernyataan)); ?>"
                                                        method="POST" class="d-inline">
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <button class="btn btn-sm btn-danger btn-delete" type="submit"
                                                            onclick="return confirm('Yakin akan menghapus data?')">Delete</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
        </section>
    </div>
    <script>
        function confirmDelete(id) {
            if (confirm('Yakin akan menghapus data?')) {
                document.getElementById('deleteForm' + id).submit();
            }
        }
    </script>
    <?php echo $__env->make('Admin.pernyataan.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('Admin.pernyataan.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
    <script>
        $('#modal-edit').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget);
            var kode = button.data('kode_pernyataan');
            var pernyataan = button.data('pernyataan');

            var modal = $(this);
            modal.find('.modal-body #kode_pernyataan').val(kode);
            modal.find('.modal-body #pernyataan').val(pernyataan);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TA\testing cf\REVISI_PROJECT\testing_project\resources\views/admin/pernyataan/index.blade.php ENDPATH**/ ?>