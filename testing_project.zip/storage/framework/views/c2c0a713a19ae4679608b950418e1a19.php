<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Data Gejala</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="<?php echo e(route('admin/home')); ?>">Dashboard</a></div>
                    <div class="breadcrumb-item">Data Gejala</div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <?php if(session()->has('pesan')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('pesan')); ?>

                                </div>
                            <?php endif; ?>
                            <div class="d-flex justify-content-end mb-3">
                                <a class="btn btn-success active" href="#" data-toggle="modal"
                                    data-target="#ModalGejala">Add Data</a>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-striped" id="table-1">
                                    <thead>
                                        <tr>
                                            <th class="text-center">#</th>
                                            <th>Kode Gejala</th>
                                            <th>Nama Gejala</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $data_gejala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_gejala_admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                                <td><?php echo e($data_gejala_admin->kode_gejala); ?></td>
                                                <td><?php echo e($data_gejala_admin->nama_gejala); ?></td>
                                                <td>
                                                    <a class="btn btn-primary active"
                                                        data-kode_gejala="<?php echo e($data_gejala_admin->kode_gejala); ?>"
                                                        data-nama_gejala="<?php echo e($data_gejala_admin->nama_gejala); ?>"
                                                        data-toggle="modal" data-target="#modal-edit">edit</a>
                                                    
                                                    <form
                                                        action="<?php echo e(route('admin/gejala/destroy', $data_gejala_admin->kode_gejala)); ?>"
                                                        method="POST" class="d-inline">
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <button class="btn btn-sm btn-danger btn-delete" type="submit"
                                                            onclick="return confirm('Yakin akan menghapus data?')">Delete</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
        </section>
    </div>

    <?php echo $__env->make('admin.gejala.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.gejala.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Script to handle modal data -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
    <script>
        $('#modal-edit').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget);
            var kode = button.data('kode_gejala');
            var nama = button.data('nama_gejala');

            var modal = $(this);
            modal.find('.modal-body #kode_gejala').val(kode);
            modal.find('.modal-body #nama_gejala').val(nama);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TA\testing cf\REVISI_PROJECT\testing_project\resources\views/Admin/gejala/index.blade.php ENDPATH**/ ?>