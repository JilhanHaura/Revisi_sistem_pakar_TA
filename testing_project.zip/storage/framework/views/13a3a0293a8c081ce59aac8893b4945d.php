<?php $__env->startSection('content'); ?>
    <!-- Carousel Start -->
    <div class="container-fluid p-0 mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div id="header-carousel" class="carousel slide carousel-fade" data-bs-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="w-100" src="/User/assets/img/carousel-3.jpg" alt="Image">
                    <div class="carousel-caption">
                        <div class="container">
                            <div class="row justify-content-start">
                                <div class="col-lg-8">
                                    <p
                                        class="d-inline-block border border-white rounded text-primary fw-semi-bold py-1 px-3 animated slideInDown">
                                        Welcome to Sistem Pakar Kesehatan Mental</p>
                                    <h1 class="display-1 mb-4 animated slideInDown">Kesehatan Mental Sangat penting Untuk
                                        Semua Orang
                                    </h1>
                                    <a href="" class="btn btn-primary py-3 px-5 animated slideInDown">Explore
                                        More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <img class="w-100" src="/User/assets/img/carousel-4.png" alt="Image">
                    <div class="carousel-caption">
                        <div class="container">
                            <div class="row justify-content-start">
                                <div class="col-lg-7">
                                    <p
                                        class="d-inline-block border border-white rounded text-primary fw-semi-bold py-1 px-3 animated slideInDown">
                                        Welcome to Sistem Pakar Kesehatan Mental</p>
                                    <h1 class="display-1 mb-4 animated slideInDown">Kami dapat membantu anda dalam
                                        melakukan deteksi dini pada kesehatan mental</h1>
                                    <a href="" class="btn btn-primary py-3 px-5 animated slideInDown">Explore
                                        More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#header-carousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#header-carousel" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>
    <!-- Carousel End -->


    <!-- About Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-4 align-items-end mb-4">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" style="width: 600px; height: auto;">
                    <img class="img-fluid rounded" src="/User/assets/img/mental.jpg" style="width: 100%; height: auto;">
                </div>

                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
                    <p class="d-inline-block border rounded text-primary fw-semi-bold py-1 px-3">Tentang Kami</p>
                    <h1 class="display-5 mb-4">Kami dapat membantu anda dalam deteksi dini pada kesehatan mental anda</h1>
                    <p class="mb-4" style="text-align: justify">Layanan kami menggunakan teknologi sistem pakar yang
                        canggih untuk membantu Anda dalam
                        mendeteksi potensi masalah kesehatan mental sejak dini. Sistem pakar ini merupakan perangkat lunak
                        yang dirancang untuk meniru kemampuan pengambilan keputusan seorang ahli di bidang kesehatan mental.
                    </p>

                    <div class="border rounded p-4">
                        <nav>
                            <div class="nav nav-tabs mb-3" id="nav-tab" role="tablist">
                                <button class="nav-link fw-semi-bold active" id="nav-story-tab" data-bs-toggle="tab"
                                    data-bs-target="#nav-story" type="button" role="tab" aria-controls="nav-story"
                                    aria-selected="true">Story</button>
                                <button class="nav-link fw-semi-bold" id="nav-mission-tab" data-bs-toggle="tab"
                                    data-bs-target="#nav-mission" type="button" role="tab" aria-controls="nav-mission"
                                    aria-selected="false">Mission</button>
                                <button class="nav-link fw-semi-bold" id="nav-vision-tab" data-bs-toggle="tab"
                                    data-bs-target="#nav-vision" type="button" role="tab" aria-controls="nav-vision"
                                    aria-selected="false">Vision</button>
                            </div>
                        </nav>

                        <div class="tab-content" id="nav-tabContent" style="text-align: justify">
                            <div class="tab-pane fade show active" id="nav-story" role="tabpanel"
                                aria-labelledby="nav-story-tab">
                                <p>Sistem pakar kesehatan mental kami dirancang untuk memberikan solusi yang cepat dan
                                    akurat dalam mendeteksi masalah kesehatan mental. Dengan menggunakan basis data yang
                                    komprehensif dan algoritma cerdas, kami dapat menyediakan penilaian awal yang bermanfaat
                                    bagi pengguna.</p>
                            </div>
                            <div class="tab-pane fade" id="nav-mission" role="tabpanel" aria-labelledby="nav-mission-tab">
                                <p>Misi kami adalah untuk meningkatkan kesejahteraan mental masyarakat dengan menyediakan
                                    alat deteksi dini yang mudah diakses dan dapat diandalkan. Kami berkomitmen untuk
                                    mendukung kesehatan mental Anda melalui teknologi inovatif.</p>
                            </div>
                            <div class="tab-pane fade" id="nav-vision" role="tabpanel" aria-labelledby="nav-vision-tab">
                                <p>Visi kami adalah menjadi pemimpin dalam teknologi kesehatan mental, menyediakan solusi
                                    yang membantu individu dalam memahami dan mengelola kondisi kesehatan mental mereka
                                    dengan lebih baik.</p>

                            </div>
                        </div>
                    </div>
                    <div class="" style="padding: 10px">
                        <a href="<?php echo e(url('/user/about')); ?>" class="btn btn-primary animated slideInDown">Explore
                            More</a>
                    </div>
                </div>
            </div>
            <div class="border rounded p-4 wow fadeInUp" data-wow-delay="0.1s">
                <div class="row g-4">
                    <div class="col-lg-4 wow fadeIn" data-wow-delay="0.1s">
                        <div class="h-100">
                            <div class="d-flex">
                                <div class="flex-shrink-0 btn-lg-square rounded-circle bg-primary">
                                    <i class="fa fa-times text-white"></i>
                                </div>
                                <div class="ps-3">
                                    <h4>No Hidden Cost</h4>
                                    <span>Layanan kami transparan tanpa biaya tersembunyi, memastikan Anda mendapatkan nilai
                                        terbaik.</span>
                                </div>
                                <div class="border-end d-none d-lg-block"></div>
                            </div>
                            <div class="border-bottom mt-4 d-block d-lg-none"></div>
                        </div>
                    </div>
                    <div class="col-lg-4 wow fadeIn" data-wow-delay="0.3s">
                        <div class="h-100">
                            <div class="d-flex">
                                <div class="flex-shrink-0 btn-lg-square rounded-circle bg-primary">
                                    <i class="fa fa-users text-white"></i>
                                </div>
                                <div class="ps-3">
                                    <h4>Dedicated Team</h4>
                                    <span>Tim kami berdedikasi untuk memberikan layanan terbaik, dengan profesional yang
                                        berpengalaman di bidang kesehatan mental dan teknologi.</span>
                                </div>
                                <div class="border-end d-none d-lg-block"></div>
                            </div>
                            <div class="border-bottom mt-4 d-block d-lg-none"></div>
                        </div>
                    </div>
                    <div class="col-lg-4 wow fadeIn" data-wow-delay="0.5s">
                        <div class="h-100">
                            <div class="d-flex">
                                <div class="flex-shrink-0 btn-lg-square rounded-circle bg-primary">
                                    <i class="fa fa-phone text-white"></i>
                                </div>
                                <div class="ps-3">
                                    <h4>24/7 Available</h4>
                                    <span>Kami selalu tersedia 24/7 untuk mendukung Anda, kapan saja Anda membutuhkan
                                        bantuan atau informasi terkait kesehatan mental.</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->


    <!-- Facts Start -->
    <div class="container-fluid facts my-5 py-5">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-sm-6 col-lg-3 text-center wow fadeIn" data-wow-delay="0.1s">
                    <i class="fa fa-users fa-3x text-white mb-3"></i>
                    <h1 class="display-4 text-white" data-toggle="counter-up">1234</h1>
                    <span class="fs-5 text-white">Happy Clients</span>
                    <hr class="bg-white w-25 mx-auto mb-0">
                </div>
                <div class="col-sm-6 col-lg-3 text-center wow fadeIn" data-wow-delay="0.3s">
                    <i class="fa fa-check fa-3x text-white mb-3"></i>
                    <h1 class="display-4 text-white" data-toggle="counter-up">1234</h1>
                    <span class="fs-5 text-white">Projects Completed</span>
                    <hr class="bg-white w-25 mx-auto mb-0">
                </div>
                <div class="col-sm-6 col-lg-3 text-center wow fadeIn" data-wow-delay="0.5s">
                    <i class="fa fa-users-cog fa-3x text-white mb-3"></i>
                    <h1 class="display-4 text-white" data-toggle="counter-up">1234</h1>
                    <span class="fs-5 text-white">Dedicated Staff</span>
                    <hr class="bg-white w-25 mx-auto mb-0">
                </div>
                <div class="col-sm-6 col-lg-3 text-center wow fadeIn" data-wow-delay="0.7s">
                    <i class="fa fa-award fa-3x text-white mb-3"></i>
                    <h1 class="display-4 text-white" data-toggle="counter-up">1234</h1>
                    <span class="fs-5 text-white">Awards Achieved</span>
                    <hr class="bg-white w-25 mx-auto mb-0">
                </div>
            </div>
        </div>
    </div>
    <!-- Facts End -->


    <!-- Features Start -->
    <div class="container-xxl feature py-5">
        <div class="container">
            <div class="row g-5 align-items-center">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                    <p class="d-inline-block border rounded text-primary fw-semi-bold py-1 px-3">Jenis-Jenis Penyakit</p>
                    <h1 class="display-5 mb-4">DASS-42 (DEPRESSION, ANXIETY, STRESS SCALE)</h1>
                    <p class="mb-4">Sistem Pakar Ini berfokus dalam kesehatan mental pada DASS-42 yaitu Depresi,
                        Kecemasan dan Stress
                    </p>
                    <a class="btn btn-primary py-3 px-5" href="<?php echo e(url('/user/jenispenyakit')); ?>">Explore More</a>
                </div>
                <div class="col-lg-6">
                    <div class="row g-4 align-items-center">
                        <div class="col-md-6">
                            <div class="row g-4">
                                <div class="col-12 wow fadeIn" data-wow-delay="0.3s">
                                    <div class="feature-box border rounded p-4">
                                        <i class="fa fa-check fa-3x text-primary mb-3"></i>
                                        <h4 class="mb-3">DEPRESI</h4>
                                        <p class="mb-3">Depresi adalah kondisi kesehatan mental yang ditandai dengan
                                            perasaan sedih yang mendalam, kehilangan minat atau kesenangan dalam aktivitas
                                            sehari-hari.</p>
                                        <a class="fw-semi-bold" href="<?php echo e(url('/user/jenispenyakit')); ?>">Read More <i
                                                class="fa fa-arrow-right ms-1"></i></a>
                                    </div>
                                </div>
                                <div class="col-12 wow fadeIn" data-wow-delay="0.5s">
                                    <div class="feature-box border rounded p-4">
                                        <i class="fa fa-check fa-3x text-primary mb-3"></i>
                                        <h4 class="mb-3">ANXIETY</h4>
                                        <p class="mb-3">Kecemasan adalah respons alami tubuh terhadap stres. Ini adalah
                                            perasaan takut atau khawatir tentang apa yang akan datang.</p>
                                        <a class="fw-semi-bold" href="<?php echo e(url('/user/jenispenyakit')); ?>">Read More <i
                                                class="fa fa-arrow-right ms-1"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 wow fadeIn" data-wow-delay="0.7s">
                            <div class="feature-box border rounded p-4">
                                <i class="fa fa-check fa-3x text-primary mb-3"></i>
                                <h4 class="mb-3">STRESS</h4>
                                <p class="mb-3">Stres adalah respons tubuh terhadap tuntutan atau tekanan dari situasi
                                    yang dianggap menantang atau mengancam. </p>
                                <a class="fw-semi-bold" href="<?php echo e(url('/user/jenispenyakit')); ?>">Read More <i
                                        class="fa fa-arrow-right ms-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Features End -->


    <!-- Callback Start -->
    
    <!-- Callback End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TA\testing cf\REVISI_PROJECT\testing_project\resources\views/home.blade.php ENDPATH**/ ?>