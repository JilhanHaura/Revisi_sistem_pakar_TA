<?php echo e($slot); ?>

<?php /**PATH D:\TA\testing cf\REVISI_PROJECT\testing_project\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>