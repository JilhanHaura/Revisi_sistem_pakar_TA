  <!-- Long Content Scroll Modal -->
  <div class="modal fade" id="modal-edit" tabindex="-1" role="dialog" aria-labelledby="scrollableModalTitle"
      aria-hidden="true">
      <div class="modal-dialog modal-dialog-scrollable" role="document">
          <div class="modal-content">
              <div class="modal-header">
                  <h5 class="modal-title" id="scrollableModalTitle">Edit Data Admin</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                  <div class="row">
                      <div class="col-12">
                          <form method="POST" action="<?php echo e(route('admin/gejala/update', $gejala->id)); ?>">
                              <?php echo csrf_field(); ?>
                              <div class="card-body">
                                  <div class="form-group">
                                      <label>Kode Gejala</label>
                                      <input type="kode_gejala" class="form-control" name="kode_gejala"
                                          value="<?php echo e(old('kode_gejala', $gejala->kode_gejala)); ?>" required>
                                      <?php $__errorArgs = ['kode_gejala'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                          <p class="text text-danger">
                                              <?php echo e($message); ?></p>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  </div>
                                  <div class="form-group">
                                      <label>Nama Gejala</label>
                                      <input type="text" class="form-control" name="nama_gejala"
                                          value="<?php echo e(old('nama_gejala', $gejala->nama_gejala)); ?>" required>
                                  </div>
                              </div>
                              <div class="d-flex justify-content-end mb-3">
                                  <button type="button" class="btn btn-light me-1"
                                      data-bs-dismiss="modal">Close</button>
                                  <button type="submit" class="btn btn-success" id="btn-save-event">Update</button>
                              </div>
                          </form>
                      </div>
                  </div>
              </div>
          </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
  </div><!-- /.modal -->
<?php /**PATH D:\TA\testing cf\REVISI_PROJECT\testing_project\resources\views/Admin/gejala/edit.blade.php ENDPATH**/ ?>