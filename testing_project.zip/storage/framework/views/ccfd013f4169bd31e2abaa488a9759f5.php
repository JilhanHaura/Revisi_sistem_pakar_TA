<?php $__env->startSection('content'); ?>
    <!-- Page Header Start -->
    <div class="container-fluid page-header mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container">
            <h1 class="display-3 mb-4 animated slideInDown">Konsultasi</h1>
            <nav aria-label="breadcrumb animated slideInDown">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Konsultasi</li>
                </ol>
            </nav>
        </div>
    </div>
    <!-- Page Header End -->
    <div class="row" style="padding-left: 30px; padding-right: 30px;">
        <div class="col-12" style="padding-bottom: 20px">
            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php echo e(session('error')); ?>

                    </ul>
                </div>
            <?php endif; ?>
            <div class="card card-primary">
                <div class="card-header">
                    <h4 style="text-align: center">Silahkan Mengisi Data Diri Sebelum Konsultasi</h4>
                </div>
                <div class="alert alert-info">
                    <strong>Disclaimer:</strong> Data yang kami tampilkan dikumpulkan dengan kerja sama Dr. Reni Iskandar,
                    M.Psi., Psikolog, dari RS M. Djamil Padang. Kami dengan tegas menjamin kerahasiaan data Anda.
                </div>
                <div class="card-body" style="padding: 15px">
                    <form method="POST" action="<?php echo e(route('user/konsultasi/store')); ?>" class="needs-validation"
                        novalidate="">
                        <?php echo csrf_field(); ?>
                        <div class="form-group" style="padding: 15px">
                            <label>User Id</label>
                            <input type="text" class="form-control" name="user_id" value="<?php echo e(Auth::user()->nik); ?>"
                                readonly>
                        </div>
                        <div class="form-group" style="padding: 15px">
                            <label>Nama</label>
                            <input type="text" class="form-control" name="nama"
                                value="<?php echo e(Auth::user()->nama_lengkap); ?>" readonly>
                        </div>

                        <div class="form-group" style="padding: 15px">
                            <div class="d-block">
                                <label for="tanggal_konsultasi" class="control-label">Tanggal Konsultasi</label>
                            </div>
                            <input id="tanggal_konsultasi" type="date" class="form-control" name="tanggal_konsultasi"
                                tabindex="3" readonly>
                            <div class="invalid-feedback">
                                please fill in your date
                            </div>
                            <?php $__errorArgs = ['tanggal_konsultasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text text-danger">
                                    <?php echo e($message); ?>

                                </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="card-header">
                            <h4 style="text-align: center">Silahkan Pilih Pernyataan yang sesuai</h4>
                        </div>
                        <div class="row" style="padding: 15px">
                            <label for=""><b><i class="fas fa-th mr-1"></i> Pernyataan-Pernyataan</b></label>
                            <div class="col-md-6">
                                <?php $__currentLoopData = $pernyataan->take(21); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="d-flex align-items-center justify-content-between border mb-2 p-2">
                                        <div>
                                            <span class="ml-2"><?php echo e($value->pernyataan); ?></span>
                                        </div>
                                        <div>
                                            
                                            <select name="skrinning[]" id=""
                                                class="form-control form-control-sm red-border">
                                                <option value="<?php echo e($value->id); ?>_0">tidak pernah</option>
                                                <option value="<?php echo e($value->id); ?>_1">Jarang</option>
                                                <option value="" selected>Tidak tahu</option>
                                                <option value="<?php echo e($value->id); ?>_2">Kadang-kadang</option>
                                                <option value="<?php echo e($value->id); ?>_3">Sering</option>
                                            </select>
                                            
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="col-md-6">
                                <?php $__currentLoopData = $pernyataan->skip(21); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="d-flex align-items-center justify-content-between border mb-2 p-2">
                                        <div>
                                            <span class="ml-2"><?php echo e($value->pernyataan); ?></span>
                                        </div>
                                        <div>
                                            
                                            <select name="skrinning[]" id=""
                                                class="form-control form-control-sm red-border">
                                                <option value="<?php echo e($value->id); ?>_0">tidak pernah</option>
                                                <option value="<?php echo e($value->id); ?>_1">Jarang</option>
                                                <option value="" selected>Tidak tahu</option>
                                                <option value="<?php echo e($value->id); ?>_2">Kadang-kadang</option>
                                                <option value="<?php echo e($value->id); ?>_3">Sering</option>
                                            </select>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="form-group" style="text-align: center; padding-top: 20px;">
                            <button type="submit" class="btn btn-primary btn-lg btn-block" tabindex="4" name="submit"
                                onclick="return validateForm()">
                                Konsultasi
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-6 mt-3" style="padding: 10px">
                <div class="row">
                    <div class="alert alert-info">
                        <h5 class="font-weight-bold"><strong>Keterangan:</strong> </h5>
                        <p>0: Tidak Pernah</p>
                        <p>1: Kadang-Kadang</p>
                        <p>2: Jarang</p>
                        <p>3: Sering</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        function validateForm() {
            var selectedOptions = document.querySelectorAll('select[name="skrinning[]"]');
            var count = 0;

            selectedOptions.forEach(function(option) {
                if (option.value !== "") {
                    count++;
                }
            });

            if (count !== selectedOptions.length) {
                alert("Harap isi semua pernyataan sebelum mengirimkan formulir.");
                return false;
            }

            return true;
        }
        document.addEventListener("DOMContentLoaded", function() {
            var currentDate = new Date();
            var year = currentDate.getFullYear();
            var month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
            var day = currentDate.getDate().toString().padStart(2, '0');
            var today = year + '-' + month + '-' + day;
            document.getElementById('tanggal_konsultasi').value = today;
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TA\testing cf\REVISI_PROJECT\testing_project\resources\views/user/konsultasi/form.blade.php ENDPATH**/ ?>