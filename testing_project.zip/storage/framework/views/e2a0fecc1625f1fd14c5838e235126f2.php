<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Data Rule</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="/dashboard">Dashboard</a></div>
                    <div class="breadcrumb-item">Data Rule</div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <?php if(session()->has('pesan')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('pesan')); ?> </div>
                            <?php endif; ?>
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="d-flex justify-content-end mb-3">
                                        <a class="btn btn-success active" href="#" data-toggle="modal"
                                            data-target="#ModalRule">Add Data</a>
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table table-striped" id="table-1">
                                            <thead>
                                                <tr>
                                                    <th class="text-center">
                                                        #
                                                    </th>
                                                    <th>Pernyataan</th>
                                                    <th>Nilai MB(H,E)</th>
                                                    <th>Nilai MD(H,E)</th>
                                                    
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                


                                                <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $basis_rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                    <tr>
                                                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                                                        <td><?php echo e($basis_rule->data_pernyataan->pernyataan); ?></td>
                                                        <td><?php echo e($basis_rule->nilai_mb); ?></td>
                                                        <td><?php echo e($basis_rule->nilai_md); ?></td>
                                                        
                                                        
                                                        <td>
                                                            
                                                            <form
                                                                action="<?php echo e(route('admin.rule.destroy', $basis_rule->rule)); ?>"
                                                                method="POST" class="d-inline">
                                                                <?php echo method_field('DELETE'); ?>
                                                                <?php echo csrf_field(); ?>
                                                                <button class="btn btn-sm btn-danger btn-delete"
                                                                    type="submit"
                                                                    onclick="return confirm('Yakin akan menghapus data?')">Delete</button>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="col-md-4" style="padding-top: 7%">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="list-group">
                                                <?php $__currentLoopData = $data_gejala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gejala): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                    <a href="<?php echo e(url(request()->fullUrlWithQuery(['gejala_id' => $gejala->kode_gejala]))); ?>"
                                                        class="list-group-item list-group-item-action gejala-item <?php if($gejala->kode_gejala == request()->input('gejala_id')): ?> active <?php endif; ?>">
                                                        <?php echo e($gejala->nama_gejala); ?>

                                                    </a>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <script>
        function confirmDelete(id) {
            if (confirm('Yakin akan menghapus data?')) {
                document.getElementById('deleteForm' + id).submit();
            }
        }
    </script>
    <script>
        // Ambil semua elemen dengan kelas 'gejala-item'
        var gejalaItems = document.querySelectorAll('.gejala-item');

        // Loop melalui setiap elemen dan tambahkan event listener untuk menangani klik
        gejalaItems.forEach(function(item) {
            item.addEventListener('click', function() {
                // Hapus kelas 'active' dari semua elemen
                gejalaItems.forEach(function(item) {
                    item.classList.remove('active');
                });
                this.classList.add('active');
            });
        });
    </script>
    <?php echo $__env->make('Admin.Rule.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('Admin.Rule.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TA\testing cf\REVISI_PROJECT\testing_project\resources\views/Admin/rule/index.blade.php ENDPATH**/ ?>